// import React from "react";

// import classes from "./PageMainCarousel.module.scss";
// import { Carousel } from "react-responsive-carousel";
// import PageMainCarouselItem, { PageMainCarouselItemProps } from "./PageMainCarousel/PageMainCarouselItem";
// import "react-responsive-carousel/lib/styles/carousel.css";

// interface PageMainCarouselProps {
//     elems: PageMainCarouselItemProps[];
// }

// const PageMainCarousel: React.FC<PageMainCarouselProps> = ({elems}) => {
//     return (
//         <div className={classes.carousel_container}>
//             <Carousel className={classes.carousel} showArrows={true} showStatus={false}>
//                 {elems.map(elem => 
//                     <PageMainCarouselItem caption={elem.caption} image={elem.image} />
//                 )}
//             </Carousel>
//         </div>
//     );
// }

// export default PageMainCarousel;